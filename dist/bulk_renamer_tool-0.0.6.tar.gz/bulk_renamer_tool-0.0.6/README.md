Bulk Renamer Tool
=================
This tool renames files in a directory "target_dir" with the file name pattern of "file_pattern" to a new file name pattern "new name".